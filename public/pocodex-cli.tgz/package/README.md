Tiny Pocodex CLI package for installing one Codex pet from pocodex.dev.
